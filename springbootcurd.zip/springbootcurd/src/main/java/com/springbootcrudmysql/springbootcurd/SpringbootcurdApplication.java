package com.springbootcrudmysql.springbootcurd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootcurdApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootcurdApplication.class, args);
	}

}
